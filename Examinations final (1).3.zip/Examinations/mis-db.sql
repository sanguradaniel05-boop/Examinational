/*
 Navicat Premium Dump SQL

 Source Server         : DataSource
 Source Server Type    : MySQL
 Source Server Version : 80045 (8.0.45)
 Source Host           : localhost:3306
 Source Schema         : examinations

 Target Server Type    : MySQL
 Target Server Version : 80045 (8.0.45)
 File Encoding         : 65001

 Date: 22/05/2026 13:11:14
*/
CREATE DATABASE mis;
USE mis;

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for programme
-- ----------------------------
DROP TABLE IF EXISTS `programme`;
CREATE TABLE `programme`  (
  `pcode` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `pname` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `duration` int NULL DEFAULT NULL,
  PRIMARY KEY (`pcode`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of programme
-- ----------------------------
INSERT INTO `programme` VALUES ('COM', 'Bsc Computer Science', 4);
INSERT INTO `programme` VALUES ('DIT', 'Diploma Information TEchnology', 3);
INSERT INTO `programme` VALUES ('SIK', 'Bsc Information Systems', 4);

-- ----------------------------
-- Table structure for student
-- ----------------------------
DROP TABLE IF EXISTS `student`;
CREATE TABLE `student`  (
  `regno` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `fname` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `lname` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `gender` enum('Female','Male') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'Female',
  `yos` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `dob` date NULL DEFAULT NULL,
  `pcode` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  PRIMARY KEY (`regno`) USING BTREE,
  INDEX `pcodefk`(`pcode` ASC) USING BTREE,
  CONSTRAINT `pcodefk` FOREIGN KEY (`pcode`) REFERENCES `programme` (`pcode`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of student
-- ----------------------------
INSERT INTO `student` VALUES ('1234', 'Kaka', 'Nana', 'Female', '1', '2026-05-22', NULL);
INSERT INTO `student` VALUES ('123456789', 'Namimi', 'Nakuja', 'Female', '4', '2026-05-12', 'DIT');
INSERT INTO `student` VALUES ('4058', 'Wantam', 'Kipwewe', 'Male', '4', '2026-05-22', 'COM');

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users`  (
  `fname` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `lname` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `username` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  PRIMARY KEY (`username` DESC) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of users
-- ----------------------------
INSERT INTO `users` VALUES ('Otanga', 'Daniel', 'dfotanga@mmust.ac.ke', 'otanga', 'otanga');
INSERT INTO `users` VALUES ('Collins', 'Odoyo', 'codoyo@mmust.ac.ke', 'odoyo', 'Odoyo123*');
INSERT INTO `users` VALUES ('Jairus', 'Odawa', 'jodawa@mmust.ac.ke', 'odawa2', 'odawa');
INSERT INTO `users` VALUES ('Moses', 'Luka', 'luka@mmust.ac.ke', 'Luka', 'luka');
INSERT INTO `users` VALUES ('James', 'Kamau', 'jkamau@iebc.org', 'Kamau', 'james123');
INSERT INTO `users` VALUES ('Jairus', 'Odawa', 'jodawa@mmust.ac.ke', 'Jairus', 'odawa');
INSERT INTO `users` VALUES ('Hellen', 'Angulu', 'hangulu@mmust.ac.ke', 'Hellen', '1234');
INSERT INTO `users` VALUES ('Raf', 'fafa', 'Raf', 'fafa', 'jaja');
INSERT INTO `users` VALUES ('Kaka', 'Kuku', 'fdfdf', 'angulu', 'sujsgjsg');

SET FOREIGN_KEY_CHECKS = 1;
