package school.examinations;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.util.StringConverter;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ResourceBundle;

public class StudentController implements Initializable {
    @FXML private RadioButton female;
    @FXML private RadioButton male;
    ToggleGroup gender = new ToggleGroup();
    @FXML private ComboBox yos;
    @FXML private ComboBox prog;
    @FXML private TextField fname;
    @FXML private TextField lname;
    @FXML private TextField regno;
    @FXML private DatePicker dob;

    public void handleSave(ActionEvent event) throws SQLException {
            String regno_str = regno.getText().trim();
            String fname_str = fname.getText().trim();
            String lname_str = lname.getText().trim();
            String sex = "";
            if(female.isSelected())
                sex = "Female";
            else if(male.isSelected())
                sex = "Male";
            String dob_str = dob.getValue().toString();
            System.out.println("Date of birth is = " + dob_str);
            String yos_str =  yos.getSelectionModel().getSelectedItem().toString();
            String prog_str = prog.getSelectionModel().getSelectedItem().toString();
            String sql_stud = "INSERT INTO student VALUES(?, ?, ?, ?, ?, ?, ?)";
            Connection conn = Connect.connection();
            PreparedStatement pst_stud = conn.prepareStatement(sql_stud);
            pst_stud.setString(1, regno_str);
            pst_stud.setString(2, fname_str);
            pst_stud.setString(3, lname_str);
            pst_stud.setString(4, sex);
            pst_stud.setString(5, yos_str);
            pst_stud.setString(6, dob_str);
            pst_stud.setString(7, prog_str);
            int x = pst_stud.executeUpdate();
            if(x > 0){
                handleCancel();
                //Alert
            }

    }
    public void handleCancel(){
        yos.getItems().clear();
        prog.getItems().clear();
        regno.clear();
        fname.clear();
        lname.clear();
        dob.setValue(null);
    }


    @Override
    public void initialize(URL location, ResourceBundle resources) {
            female.setToggleGroup(gender);
            male.setToggleGroup(gender);
            Integer [] yosItems = {1, 2, 3, 4, 5, 6};
            ObservableList<Integer> yosList = FXCollections.observableArrayList(yosItems);
            yos.setItems(yosList);

            ObservableList<String> progItems = FXCollections.observableArrayList();
            Connection conn = Connect.connection();
            String sqlProgs = "SELECT pcode, pname FROM programme";
        try {
            PreparedStatement pstProgs = conn.prepareStatement(sqlProgs);
            ResultSet rsProgs = pstProgs.executeQuery();
            while(rsProgs.next()) {
                progItems.add(rsProgs.getString("pcode"));
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        prog.setItems(progItems);
        // 1. Define the desired pattern
        String pattern = "yyyy-MM-dd";
        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern(pattern);

        // 2. Create and set the StringConverter
        dob.setConverter(new StringConverter<LocalDate>() {
            @Override
            public String toString(LocalDate date) {
                if (date != null) {
                    return dateFormatter.format(date);
                } else {
                    return "";
                }
            }

            @Override
            public LocalDate fromString(String string) {
                if (string != null && !string.trim().isEmpty()) {
                    return LocalDate.parse(string, dateFormatter);
                } else {
                    return null;
                }
            }
        });

        // Optional: Set current date as default
        dob.setValue(LocalDate.now());

    }
}
